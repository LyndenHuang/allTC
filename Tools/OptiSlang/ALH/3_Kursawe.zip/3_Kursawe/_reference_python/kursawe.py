# ------------------------------------------------------------------------------------------------------------------ #
#
#   DYNARDO example
#
#   Kursawe functions (multi objective optimization)
#
#    f1(x) = SUM_{i=1,...,n-1} (-10 exp(-0.2*sqrt(x_i^2 + x_(i+1)^2) ) )
#    f2(x) = SUM_{i=1,...,n} ( |x_i|^0.8 + 5 sin(x_i)^3)
#    x \in R^n (n=3)
#
#       f1(x), f2(x) -> min
#       -5 <= x_i <= 5, i=1,...,n
#
# ------------------------------------------------------------------------------------------------------------------ #


# ------------------------------------------------------------------------------------------------------------------ #
#   Reference values
# ------------------------------------------------------------------------------------------------------------------ #
from math import exp, pow, sqrt, sin

# Check if Python is called outside optiSLang
if not 'OSL_REGULAR_EXECUTION' in locals(): 
    OSL_REGULAR_EXECUTION = False

# values to default if not existing yet
if not OSL_REGULAR_EXECUTION: # test run mode
    x_1 = 0.0
    x_2 = 0.0
    x_3 = 0.0

# ------------------------------------------------------------------------------------------------------------------ #
#   Results
# ------------------------------------------------------------------------------------------------------------------ #

kursawe1 = -10 * exp(-0.2*sqrt(x_1*x_1 + x_2*x_2) )
kursawe1 = kursawe1 - 10 * exp(-0.2*sqrt(x_2*x_2 + x_3*x_3) )

print("kursawe1: " + str(kursawe1))

kursawe2 = pow(abs(x_1),0.8) + 5*pow(sin(x_1),3)
kursawe2 = kursawe2 + pow(abs(x_2),0.8) + 5*pow(sin(x_2),3)
kursawe2 = kursawe2 + pow(abs(x_3),0.8) + 5*pow(sin(x_3),3)

print("kursawe2: " + str(kursawe2))
