=================================================================

	Calibre 3DThermal Tutorial
	Siemens EDA
	2024

=================================================================

This is a generic example. It is not intended to represent a realistic design case.
This demo case does not include the powermap extraction and compressed power preparation for thermal simulation

There are 4 dies in the package:
- 2 controller dies (controller.oas)
- 2 stacked memory dies (memory.gds)


FILES:

     Set up:
     - sourceme                      : Edit the sourceme file to point to the appropriate license and software installations, and source this file.

           setenv LM_LICENSE_FILE <add your licenses here>
           setenv MGC_HOME <path to Calibre installation>


     Run scripts:
     - 1. extraction/run_effp        : Run script for thermal property extraction
     - 2. run_ta                     : Run script for thermal simulation
     - 3. run_drv                    : Run script for viewing results using DESIGNrev and RVE
     - 4. run_thermgui               : Run script for viewing results using thermal analysis GUI
     - 5. run_create_assembly_only   : Run script for creating the assembly OASIS only
     - 6. run_assembly_view          : Run script for viewing model assembly 

     Inputs:
     - design/                       : Directory containing the GDS/OASIS layouts and power map files for the dies
     - power/power_die.txt           : A power map that creates a uniform power over the controller die
     - power/power_die_transient.txt : A transient map that includes a time-varying power over a region for the controller die
     - power/power_mem.txt           : A power map that creates power tiles across the memory die
     - layout/controller.oas         : Controller layout
     - layout/memory.gds             : Memory layout
     - extraction/effp.cfg           : Material extraction configuration
     - ta.cfg                        : Configuration file for thermal simulation

     Outputs:
     - extraction/controller_props.txt  : Extracted thermal properties file for controller die used in thermal simulation
     - demo_drv.tcl                     : DESIGNrev TCL script for assembly layout
     - demo.sum                         : Summary of thermal results
     - demo_dfmdb                       : Results database for thermal analysis GUI
     - demo_power.rdb                   : Power RDB
     - demo_composite.rdb               : Extracted thermal properties RDB 
     - demo_map.rdb                     : Thermal results RDB for transient simulation
     - demo_wf.rdb                      : Locations of monitor points for thermal waveforms
     - *.wdb                            : Solido Waveform Analyzer database for transient temperature and power results view

STEPS:

     1. Prepare the sourceme file and source it.
     2. Run "run_effp" to extract the effective thermal properties for each controller die.
     3. Run "run_ta" to perform thermal simulation. This uses the output from step 2.
     4. Run "run_drv" to view the assembly and results using DRV and RVE.
     5. Run "run_thermgui" to view the results using the thermal GUI.


